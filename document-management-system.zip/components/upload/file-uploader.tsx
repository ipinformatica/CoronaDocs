'use client'

import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  Upload,
  FileText,
  X,
  CheckCircle,
  AlertCircle,
  Loader2,
  ImageIcon,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface UploadFile {
  id: string
  file: File
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'error'
  progress: number
  error?: string
  result?: {
    documentType: string
    confidence: number
  }
}

interface FileUploaderProps {
  onUploadComplete?: (files: UploadFile[]) => void
}

export function FileUploader({ onUploadComplete }: FileUploaderProps) {
  const [files, setFiles] = useState<UploadFile[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles: UploadFile[] = acceptedFiles.map((file) => ({
      id: Math.random().toString(36).substring(7),
      file,
      status: 'pending',
      progress: 0,
    }))
    setFiles((prev) => [...prev, ...newFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/tiff': ['.tiff', '.tif'],
    },
    maxSize: 50 * 1024 * 1024, // 50MB
  })

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id))
  }

  const simulateProcessing = async () => {
    setIsProcessing(true)

    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      if (file.status !== 'pending') continue

      // Update to uploading
      setFiles((prev) =>
        prev.map((f) =>
          f.id === file.id ? { ...f, status: 'uploading', progress: 0 } : f
        )
      )

      // Simulate upload progress
      for (let p = 0; p <= 100; p += 20) {
        await new Promise((r) => setTimeout(r, 100))
        setFiles((prev) =>
          prev.map((f) => (f.id === file.id ? { ...f, progress: p } : f))
        )
      }

      // Update to processing
      setFiles((prev) =>
        prev.map((f) =>
          f.id === file.id ? { ...f, status: 'processing', progress: 100 } : f
        )
      )

      // Simulate AI processing
      await new Promise((r) => setTimeout(r, 1500))

      // Random success/error
      const isSuccess = Math.random() > 0.1
      setFiles((prev) =>
        prev.map((f) =>
          f.id === file.id
            ? {
                ...f,
                status: isSuccess ? 'completed' : 'error',
                error: isSuccess ? undefined : 'Error al procesar el documento',
                result: isSuccess
                  ? {
                      documentType: ['FACTURA_COMPRA', 'FACTURA_VENTA', 'ALBARAN_COMPRA'][
                        Math.floor(Math.random() * 3)
                      ],
                      confidence: Math.floor(Math.random() * 30) + 70,
                    }
                  : undefined,
              }
            : f
        )
      )
    }

    setIsProcessing(false)
    onUploadComplete?.(files)
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return <ImageIcon className="h-5 w-5" />
    }
    return <FileText className="h-5 w-5" />
  }

  const getStatusIcon = (status: UploadFile['status']) => {
    switch (status) {
      case 'uploading':
      case 'processing':
        return <Loader2 className="h-5 w-5 animate-spin text-blue-400" />
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-400" />
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-400" />
      default:
        return null
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const pendingCount = files.filter((f) => f.status === 'pending').length
  const completedCount = files.filter((f) => f.status === 'completed').length

  return (
    <div className="space-y-6">
      {/* Drop Zone */}
      <div
        {...getRootProps()}
        className={cn(
          'border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors',
          isDragActive
            ? 'border-primary bg-primary/5'
            : 'border-border hover:border-primary/50 hover:bg-secondary/50'
        )}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
            <Upload className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="text-lg font-medium text-foreground">
              {isDragActive
                ? 'Suelta los archivos aqui...'
                : 'Arrastra y suelta archivos aqui'}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              o haz clic para seleccionar archivos
            </p>
          </div>
          <p className="text-xs text-muted-foreground">
            Formatos soportados: PDF, JPG, PNG, TIFF (max. 50MB)
          </p>
        </div>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="space-y-3">
              {files.map((uploadFile) => (
                <div
                  key={uploadFile.id}
                  className="flex items-center gap-4 rounded-lg border border-border p-3"
                >
                  {/* File Icon */}
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                    {getFileIcon(uploadFile.file)}
                  </div>

                  {/* File Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">
                        {uploadFile.file.name}
                      </p>
                      {getStatusIcon(uploadFile.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(uploadFile.file.size)}
                      {uploadFile.result && (
                        <span className="ml-2">
                          • {uploadFile.result.documentType} ({uploadFile.result.confidence}% confianza)
                        </span>
                      )}
                      {uploadFile.error && (
                        <span className="ml-2 text-red-400">{uploadFile.error}</span>
                      )}
                    </p>
                    {(uploadFile.status === 'uploading' ||
                      uploadFile.status === 'processing') && (
                      <Progress value={uploadFile.progress} className="mt-2 h-1" />
                    )}
                  </div>

                  {/* Remove Button */}
                  {uploadFile.status === 'pending' && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => removeFile(uploadFile.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="mt-4 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {completedCount} de {files.length} procesados
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => setFiles([])}
                  disabled={isProcessing}
                >
                  Limpiar
                </Button>
                <Button
                  onClick={simulateProcessing}
                  disabled={pendingCount === 0 || isProcessing}
                  className="gap-2"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Procesando...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4" />
                      Procesar {pendingCount} archivo(s)
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
